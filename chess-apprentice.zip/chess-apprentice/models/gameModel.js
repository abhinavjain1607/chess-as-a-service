var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var { colorEnums } = require("../constants/pieceColors");

var gameSchema = new Schema({
	name: { type: String, required: true, default: "" },
	board: {
		type: [
			[
				{
					piece: { type: String },
					pos: { type: String },
					color: {
						type: String,
						enum: colorEnums,
					},
					isEmpty: { type: Boolean, required: true },
				},
			],
		],
		isRequired: true,
		default: [],
		index: true,
	},
	players: {
		type: [
			{
				playerId: { type: String, required: true, default: "dummy" },
				pieceColor: { type: String, required: true, enum: colorEnums },
				type: { type: String, required: true, default: "human" },
			},
		],
		isRequired: true,
		default: [],
		index: true,
	},
	settings: {},
	nextTurn: {
		pieceColor: { type: String, required: true, enum: colorEnums },
	},
});

module.exports = mongoose.model("game", gameSchema);
