# chess-as-a-service

To get started, do `npm install`
This will start your server on port 3002

To use the APIs, you can go to the _postman collection_ present in the repository and the _environment_.

You will have _4 APIs_ that you can play with

1. _Create a game_ - Creates a game of chess with initial board setup
    - Please use the `_id` returned in the response to put in the postman environment variable `gameId` to play that game
2. _Get game_ - Returns the current state of the game
3. _Move a piece_ - Validates a move and makes a move
4. _Potential moves_ - Find potential moves for a piece on the board
5. _Fetch moves history_ - Returns 502 gateway as of now

Enjoy the game!
