var { gridToIndex } = require("../../constants/boardpositions");

const findPieceAtPosition = (board, pos) => {
	const [row, col] = getIndexes(pos);
	return board[row][col];
};

const getIndexes = (pos) => [
	gridToIndex.row[pos[1]].position,
	gridToIndex.col[pos[0]].position,
];

const isValidPosition = (gridPosition) => {
	return (
		gridPosition &&
		gridPosition.length == 2 &&
		gridPosition[0] in gridToIndex.col &&
		gridPosition[1] in gridToIndex.row
	);
};

const beautifyBoard = (board) => {
	const initialRow = ["-  a  b  c  d  e  f  g  h"];
	return initialRow.concat(
		board.map((row, index) => {
			let str = row.length - index + "  ";
			row.map((p) => {
				str += (p.piece + p.color || "--") + " ";
			});
			return str;
		})
	);
};

module.exports = {
	findPieceAtPosition,
	getIndexes,
	isValidPosition,
	beautifyBoard,
};
