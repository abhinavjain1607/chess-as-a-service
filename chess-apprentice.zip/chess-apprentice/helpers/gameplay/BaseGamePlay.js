var { indexToGrid } = require("../../constants/boardpositions");
const { newPiece, emptyPiece } = require("../game");
class BaseGamePlay {
	getPiece = (board, coords) => {
		return board[coords[0]][coords[1]];
	};

	getPieceColor = (board, coords) => {
		return this.getPiece(board, coords).color;
	};

	addMove = (finalCoords, moveCoords, capture) => {
		return finalCoords.push({
			pos: `${indexToGrid.col[moveCoords[1]]}${
				indexToGrid.row[moveCoords[0]]
			}`,
			capture,
		});
	};

	doesPieceExist = (board, coords) => {
		return !this.getPiece(board, coords).isEmpty;
	};

	areOppositePieces = (board, sourceCoords, destiCoords) =>
		this.doesPieceExist(board, sourceCoords) &&
		this.doesPieceExist(board, destiCoords) &&
		this.getPieceColor(board, destiCoords) !==
			this.getPieceColor(board, sourceCoords);

	isValidCoords = (moveCoords) => {
		if (
			moveCoords[0] >= 0 &&
			moveCoords[0] <= 7 &&
			moveCoords[1] >= 0 &&
			moveCoords[1] <= 7
		)
			return true;
		return false;
	};

	updateBoardWithAMove = (board, sourceCoords, destiCoords) => {
		let sourcePiece = this.getPiece(board, sourceCoords);
		let destinationPiece = this.getPiece(board, destiCoords);

		destinationPiece = newPiece(
			sourcePiece.piece,
			destinationPiece.pos,
			sourcePiece.color
		);
		sourcePiece = emptyPiece(sourcePiece.pos);

		board[sourceCoords[0]][sourceCoords[1]].set(sourcePiece);
		board[destiCoords[0]][destiCoords[1]].set(destinationPiece);

		return board;
	};
}

module.exports = BaseGamePlay;
