const { colorEnums } = require("../../constants/pieceColors");
const { findPieceAtPosition } = require("./helper");
var PawnGamePlay = require("./PawnGamePlay");

class GamePlay {
	constructor(pawnGamePlay) {
		this.pawnGamePlay = pawnGamePlay;
	}

	findPieceGamePlay = (piece) => {
		switch (piece.piece) {
			case "P":
				return this.pawnGamePlay;
			default:
				throw new Error("move not implmented for piece");
		}
	};

	findPotentialSpaces = (board, gridPos) => {
		const piece = findPieceAtPosition(board, gridPos);

		if (piece.isEmpty) {
			throw new Error("No piece at the provided position");
		}

		const gamePlay = this.findPieceGamePlay(piece);

		return gamePlay.findPotentialSpaces(board, gridPos);
	};

	makeAMove = (game, sourcePos, destinationPos) => {
		const sourcePiece = findPieceAtPosition(game.board, sourcePos);

		if (sourcePiece.isEmpty) {
			throw new Error("No piece at the provided source position");
		}
		if (game.nextTurn.pieceColor !== sourcePiece.color) {
			throw new Error(game.nextTurn.pieceColor + " should play next");
		}

		const gamePlay = this.findPieceGamePlay(sourcePiece);

		gamePlay.makeAMove(game.board, sourcePos, destinationPos);

		const nextColor =
			colorEnums[0] === game.nextTurn.pieceColor
				? colorEnums[1]
				: colorEnums[0];

		game.set("nextTurn.pieceColor", nextColor);
	};
}

module.exports = new GamePlay(new PawnGamePlay());
