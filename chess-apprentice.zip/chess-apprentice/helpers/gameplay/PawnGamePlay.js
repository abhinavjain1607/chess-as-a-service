const { colors } = require("../../constants/pieceColors");
const { getIndexes } = require("./helper");
const BaseGamePlay = require("../gameplay/BaseGamePlay");
const GameModel = require("../../models/gameModel");

class PawnGamePlay extends BaseGamePlay {
	constructor() {
		super();
		this.initialWhitePosition = 6;
		this.initialBlackPosition = 1;
	}

	isCoordsRightForAttack = (board, sourceCoords, destiCoords) => {
		if (this.getPieceColor(board, sourceCoords) === colors.White) {
			return (
				destiCoords[0] - sourceCoords[0] === -1 &&
				Math.abs(destiCoords[1] - sourceCoords[1]) === 1
			);
		} else {
			return (
				destiCoords[0] - sourceCoords[0] === 1 &&
				Math.abs(destiCoords[1] - sourceCoords[1]) === 1
			);
		}
	};

	isCoordsRightForFrontMove = (board, sourceCoords, destiCoords) => {
		if (this.getPieceColor(board, sourceCoords) === colors.White) {
			if (
				this.doesPieceExist(board, [
					sourceCoords[0] - 1,
					sourceCoords[1],
				])
			)
				return false;
			if (sourceCoords[0] === this.initialWhitePosition) {
				return (
					destiCoords[0] - sourceCoords[0] >= -2 &&
					destiCoords[1] === sourceCoords[1]
				);
			}
			return (
				destiCoords[0] - sourceCoords[0] === -1 &&
				destiCoords[1] === sourceCoords[1]
			);
		} else {
			if (
				this.doesPieceExist(board, [
					sourceCoords[0] + 1,
					sourceCoords[1],
				])
			)
				return false;
			if (sourceCoords[0] === this.initialBlackPosition) {
				return (
					destiCoords[0] - sourceCoords[0] <= 2 &&
					destiCoords[1] === sourceCoords[1]
				);
			}
			return (
				destiCoords[0] - sourceCoords[0] === 1 &&
				destiCoords[1] === sourceCoords[1]
			);
		}
	};

	isValidFrontMove = (board, sourceCoords, destiCoords) => {
		return (
			this.isValidCoords(sourceCoords) &&
			this.isValidCoords(destiCoords) &&
			!this.doesPieceExist(board, destiCoords) &&
			this.isCoordsRightForFrontMove(board, sourceCoords, destiCoords)
		);
	};

	isValidAttackMove = (board, sourceCoords, destiCoords) => {
		return (
			this.isValidCoords(sourceCoords) &&
			this.isValidCoords(destiCoords) &&
			this.areOppositePieces(board, sourceCoords, destiCoords) &&
			this.isCoordsRightForAttack(board, sourceCoords, destiCoords)
		);
	};

	validateAndAddFrontMove = (
		potentialSpaces,
		board,
		sourceCoords,
		destiCoords
	) => {
		this.isValidFrontMove(board, sourceCoords, destiCoords) &&
			this.addMove(potentialSpaces, destiCoords, false);
	};

	validateAndAddAttackMove = (
		potentialSpaces,
		board,
		sourceCoords,
		destiCoords
	) => {
		this.isValidAttackMove(board, sourceCoords, destiCoords) &&
			this.addMove(potentialSpaces, destiCoords, true);
	};

	findAttackMoves = (potentialSpaces, board, sourceCoords) => {
		const piece = this.getPiece(board, sourceCoords);
		if (piece.color === colors.White) {
			this.validateAndAddAttackMove(
				potentialSpaces,
				board,
				sourceCoords,
				[sourceCoords[0] - 1, sourceCoords[1] - 1]
			);
			this.validateAndAddAttackMove(
				potentialSpaces,
				board,
				sourceCoords,
				[sourceCoords[0] - 1, sourceCoords[1] + 1]
			);
		} else {
			this.validateAndAddAttackMove(
				potentialSpaces,
				board,
				sourceCoords,
				[sourceCoords[0] + 1, sourceCoords[1] + 1]
			);
			this.validateAndAddAttackMove(
				potentialSpaces,
				board,
				sourceCoords,
				[sourceCoords[0] + 1, sourceCoords[1] - 1]
			);
		}
	};

	findFrontMoves = (potentialSpaces, board, sourceCoords) => {
		const piece = this.getPiece(board, sourceCoords);
		if (piece.color === colors.White) {
			if (sourceCoords[0] === this.initialWhitePosition) {
				this.validateAndAddFrontMove(
					potentialSpaces,
					board,
					sourceCoords,
					[sourceCoords[0] - 2, sourceCoords[1]]
				);
			}
			this.validateAndAddFrontMove(potentialSpaces, board, sourceCoords, [
				sourceCoords[0] - 1,
				sourceCoords[1],
			]);
		} else {
			if (sourceCoords[0] === this.initialBlackPosition) {
				this.validateAndAddFrontMove(
					potentialSpaces,
					board,
					sourceCoords,
					[sourceCoords[0] + 2, sourceCoords[1]]
				);
			}
			this.validateAndAddFrontMove(potentialSpaces, board, sourceCoords, [
				sourceCoords[0] + 1,
				sourceCoords[1],
			]);
		}
	};

	findPotentialSpaces = (board, gridPos) => {
		const sourceCoords = getIndexes(gridPos);
		let potentialSpaces = [];
		this.findFrontMoves(potentialSpaces, board, sourceCoords);
		this.findAttackMoves(potentialSpaces, board, sourceCoords);

		return potentialSpaces;
	};

	makeAMove = (board, sourcePos, destinationPos) => {
		const sourceCoords = getIndexes(sourcePos);
		const destiCoords = getIndexes(destinationPos);
		if (
			!this.isValidFrontMove(board, sourceCoords, destiCoords) &&
			!this.isValidAttackMove(board, sourceCoords, destiCoords)
		) {
			throw new Error(
				`Invalid Move from ${sourcePos} => ${destinationPos}`
			);
		}

		return this.updateBoardWithAMove(board, sourceCoords, destiCoords);
	};
}

module.exports = PawnGamePlay;
