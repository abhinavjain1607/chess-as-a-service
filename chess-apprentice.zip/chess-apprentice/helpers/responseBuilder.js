module.exports = {
	builder(response, data = '') {
		if (data instanceof Error) {
			let statusCode = 500;
			if (data.statusCode) statusCode = data.statusCode;
			response.status(statusCode).json({ error: data.message });
		} else response.status(200).json(data);
	},
	getError(data, statusCode) {
		const err = new Error();
		if (data instanceof Error) err.message = data.message;
		else err.message = data;
		if (statusCode) err.statusCode = statusCode;
		else err.statusCode = 500;
		return err;
	},
};
