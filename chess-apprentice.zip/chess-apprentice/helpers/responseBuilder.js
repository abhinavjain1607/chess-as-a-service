const PieceNotImplementedError = require("./PieceNotImplementedError");

module.exports = {
	builder(response, data = "") {
		return response.status(200).json(data);
	},
	getError(response, data, statusCode = 500) {
		return response.status(statusCode).json({
			message: data.message,
			success: false,
			error: data,
		});
	},
};
