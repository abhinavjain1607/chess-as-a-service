class PieceNotImplementedError extends Error {
	constructor(message) {
		super(message);
		this.name = "PieceNotImplementedError";
		this.errorCode = "101";
	}
}

module.exports = PieceNotImplementedError;
