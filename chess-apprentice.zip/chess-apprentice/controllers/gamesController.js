const responseBuilder = require("../helpers/responseBuilder");
var GameRepository = require("../repositories/GameRepository");
var { gridToIndex } = require("../constants/boardpositions");
const {
	isValidPosition,
	beautifyBoard,
} = require("../helpers/gameplay/helper");

const createGame = async (req, res) => {
	try {
		const payload = req.body;
		if (!payload.name) {
			payload.name = "dummy";
		}
		const game = await GameRepository.createNewGame(payload);
		return responseBuilder.builder(res, {
			success: true,
			viewGame: beautifyBoard(game.board),
			nextTurn: game.nextTurn.pieceColor,
			game,
		});
	} catch (error) {
		return responseBuilder.getError(res, error, 422);
	}
};

const getGame = async (req, res) => {
	try {
		const game = await GameRepository.getGame(req.params.id);
		return responseBuilder.builder(res, {
			success: true,
			viewGame: beautifyBoard(game.board),
			nextTurn: game.nextTurn.pieceColor,
			game,
		});
	} catch (error) {
		return responseBuilder.getError(res, error, 422);
	}
};

const findPotentialSpaces = async (req, res) => {
	try {
		if (!isValidPosition(req.params.pos)) {
			throw new Error(`Incorrect position passed: ${req.params.pos}`);
		}

		const { potentialSpaces, game } =
			await GameRepository.findPotentialSpaces(
				req.params.id,
				req.params.pos
			);
		return responseBuilder.builder(res, {
			success: true,
			potentialSpaces,
			beautifyBoard: beautifyBoard(game.board),
		});
	} catch (error) {
		return responseBuilder.getError(res, error, 422);
	}
};

const makeAMove = async (req, res) => {
	const { sourcePos, destinationPos } = req.body;
	try {
		if (!isValidPosition(sourcePos)) {
			throw new Error(`Incorrect source position passed: ${sourcePos}`);
		}
		if (!isValidPosition(destinationPos)) {
			throw new Error(
				`Incorrect destination position passed: ${destinationPos}`
			);
		}

		const game = await GameRepository.makeAMove(
			req.params.id,
			sourcePos,
			destinationPos
		);

		return responseBuilder.builder(res, {
			beautifyBoard: beautifyBoard(game.board),
			nextTurn: game.nextTurn.pieceColor,
		});
	} catch (error) {
		return responseBuilder.getError(res, error, 422);
	}
};

const getMovesHistory = async (req, res) => {
	return responseBuilder.builder(
		res,
		responseBuilder.getError("Method not implemented as per date.", 502)
	);
};

module.exports = {
	createGame,
	getGame,
	findPotentialSpaces,
	makeAMove,
	getMovesHistory,
};
