var express = require("express");
var router = express.Router();
var gamesController = require("../controllers/gamesController");

/* GET users listing. */
router.post("/", gamesController.createGame);
router.get("/:id", gamesController.getGame);
router.get("/:id/potential-moves/:pos", gamesController.findPotentialSpaces);
router.post("/:id/move", gamesController.makeAMove);
router.get("/:id/moves-history", gamesController.getMovesHistory);
module.exports = router;
