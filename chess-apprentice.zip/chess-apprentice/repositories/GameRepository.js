const GameModel = require("../models/gameModel");
const { newBoard, newPiece } = require("../helpers/game");
const GamePlay = require("../helpers/gameplay/Gameplay");

class GameRepository {
	async createNewGame({ name }) {
		return GameModel.create({
			name,
			board: newBoard,
			players: [
				{
					playerId: 1,
					pieceColor: "W",
					type: "human",
				},
				{
					playerId: 1,
					pieceColor: "B",
					type: "human",
				},
			],
			nextTurn: {
				pieceColor: "W",
			},
		});
	}

	getGame = (id) => {
		return GameModel.findById(id).exec();
	};

	findPotentialSpaces = async (id, gridPosition) => {
		const game = await this.getGame(id);

		return {
			potentialSpaces: GamePlay.findPotentialSpaces(
				game.board,
				gridPosition
			),
			game,
		};
	};

	makeAMove = async (id, sourcePos, destinationPos) => {
		const game = await this.getGame(id);

		GamePlay.makeAMove(game, sourcePos, destinationPos);

		game.save();

		return game;
	};
}

module.exports = new GameRepository();
