const colors = { White: "W", Black: "B" };

module.exports = {
	colors,
	colorEnums: Object.values(colors),
};
