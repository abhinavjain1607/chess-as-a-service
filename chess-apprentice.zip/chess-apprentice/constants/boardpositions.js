/**
 * Keys represent grid system in chess
 * Key in row are row values in grid system
 * Key in col are col values in grid system
 * Position is where they are located in the board
 * For example, a1 is at the bottom of the board so its coordinates would be (7,0)
 */
const gridToIndex = {
	row: {
		8: { position: 0 },
		7: { position: 1 },
		6: { position: 2 },
		5: { position: 3 },
		4: { position: 4 },
		3: { position: 5 },
		2: { position: 6 },
		1: { position: 7 },
	},
	col: {
		a: { position: 0 },
		b: { position: 1 },
		c: { position: 2 },
		d: { position: 3 },
		e: { position: 4 },
		f: { position: 5 },
		g: { position: 6 },
		h: { position: 7 },
	},
};

const indexToGrid = {
	row: {},
	col: {},
};

Object.keys(gridToIndex.row).map((key) => {
	indexToGrid.row[gridToIndex.row[key].position] = key;
});

Object.keys(gridToIndex.col).map((key) => {
	indexToGrid.col[gridToIndex.col[key].position] = key;
});

module.exports = { gridToIndex, indexToGrid };
